%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Reglerentwurf nach dem Frequnezkennlinienverfahren  %%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear all
% clc


% Regelstrecke PT2-Verhalten (realer Aufbau)
Ks = 1;
T0 = 1;
Damp = 0.8;
Tt = 0.4;


%% a) Ergebnisse aus �bung 5 mit Gs = Ks/((1+T1_1*s)*exp(-s*Tt_1))
% Parameter der Regelstrecke PT1 (aus �bung)
Ks = 1;
T1_1 = 1.8;
Tt_1 = 1.2;

% Parameter des Reglers
Tn1 = T1_1;
Kp1 = pi*T1_1/(6*Tt_1*Ks);



%% b) SISOTOOL anwenden
s = tf('s');

Gs = Ks/((1+2*Damp*T0*s+T0^2*s^2))*exp(-s*Tt);


% Regler 
Kp2 = 1;
Tn2 = 1;       %T0
Gr = Kp2*(1+s*Tn2)/(s*Tn2);


% Aufruf SISOTOOL
%sisotool(Gs,Gr)



%% 4.2
% 
Ki = 3000;
T1 = 3e-3;
Gs = Ki/(s*(1+T1*s));

Kp = 1;
Tn = 4*T1
Gr = Kp*(1+s*Tn)/(s*Tn);

%sisotool(Gs,Gr)











