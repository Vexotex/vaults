%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Parameter f�r den Antrieb mit Gleichstrommaschine       %%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear all
clc
%% Parameter der Regelstrecke

% Parameter der Maschine
Rq=0.25;        %Ankerwiderstand der SM
Lq=24e-3;       %Induktivit�t der SM
Tq=Lq/Rq;       % Ankerzeitkonstante in s
p=5;            %Polpaarzahl
psi_d=9.4e-3; %Verkettungsfluss (d-Achse)
km=2/pi*p*psi_d;   %Maschinenkonstante

% Parameter des Umrichters
fs=16e3;        % Schaltfrequenz in Hz
Ts=1/fs;        % Periondendauer in s
Tt=Ts/2;        % statistische SR-Totzeit

% Parameter des mechanischen Modells (Einmassensystem)
J=0.28e-3;         % Gesamttr�gheitsmoment von Antrieb, Getriebe und Last in Nm (kg*m^2)

% Parameter der Messwerterfasung
Tmi=500e-6;      % Ersatzzeitkonstante (PT1-Glied) in s
Tmw=2e-3;        % Ersatzzeitkonstante in s

