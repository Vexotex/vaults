%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Reglerentwurf nach dem Frequnezkennlinienverfahren  %%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear all
% clc

%% a) Ergebnisse aus �bung 5 mit Gs = Ks/((1+T1_1*s)*exp(-s*Tt_1))
% Parameter der Regelstrecke
Ks = 1;
T1_1 = 1.8;
Tt_1 = 1.2;

% Parameter des Reglers
Tn1 = T1_1;
Kp1 = pi*T1_1/(6*Tt_1*Ks);

